package us.ait.budgetbuddy

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import kotlinx.android.synthetic.main.bud_dialog.view.*
import us.ait.budgetbuddy.data.BudClass
import java.lang.RuntimeException
import java.util.*

class BudDialog: DialogFragment() {

    interface BudHandler {
        fun budCreated(todo: BudClass)
    }
    lateinit var budHandler: BudHandler

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is BudHandler) {
            budHandler = context
        } else {
            throw RuntimeException(
                R.string.error.toString()
            )
        }
    }

    lateinit var etBudName : EditText
    lateinit var etBudPrice: EditText
    lateinit var spinnerCategory : Spinner

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val dialogBuilder = AlertDialog.Builder(requireContext())

        dialogBuilder.setTitle(R.string.newitemcreated)//

        val dialogView = requireActivity().layoutInflater.inflate(
            R.layout.bud_dialog, null
        )
        etBudName = dialogView.etBudName
        etBudPrice = dialogView.etBudPrice
        spinnerCategory=dialogView.spinnerCategory



        val categoriesAdapter= ArrayAdapter.createFromResource(
            requireContext(), R.array.categories_array, android.R.layout.simple_spinner_item
        )

        categoriesAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        spinnerCategory.adapter=categoriesAdapter

        dialogBuilder.setView(dialogView)


        dialogBuilder.setPositiveButton( R.string.ok) {
                dialog, which ->

        }
        dialogBuilder.setNegativeButton(R.string.cancel) {
                dialog, which ->

        }

        return dialogBuilder.create()
    }

    override fun onResume() {
        super.onResume()

        val dialog = dialog as AlertDialog
        val positiveButton = dialog.getButton(Dialog.BUTTON_POSITIVE)

        positiveButton.setOnClickListener {
            if (etBudName.text.isNotEmpty()) {
                if (etBudPrice.text.isNotEmpty()) {
                    handleBudCreate()
                    dialog.dismiss()
                } else {
                    etBudPrice.error = R.string.emptyerror.toString()
                }

            } else {
                etBudName.error = R.string.emptyerror.toString()
            }
        }
    }

    private fun handleBudCreate() {
        budHandler.budCreated(BudClass(
            null,
            etBudName.text.toString(),
            etBudPrice.text.toString(),
            spinnerCategory.selectedItemPosition))

    }


}