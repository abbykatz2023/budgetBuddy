package us.ait.budgetbuddy

import android.R
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_summary.*
import org.eazegraph.lib.models.PieModel


class SummaryActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(us.ait.budgetbuddy.R.layout.activity_summary)


        var color1 = "#9984BF"
        var color2 = "#FDA5C3"
        var color3 = "#86C5F8"
        var color4 = "#65ACA5"
        var color5 = "#F49D82"
        var color6 = "#FBF29E"


        var total = intent.getStringExtra(ScrollingActivity.KEY_TOTAL)
        //}
        if (intent.hasExtra(ScrollingActivity.KEY_FOOD)) {
            var food = intent.getStringExtra(ScrollingActivity.KEY_FOOD)
            var foodPercent = ((Integer.parseInt(food)).toDouble() / (Integer.parseInt(total)).toDouble()).times(100.0).toInt().toString()
            tvFoodNum.text = foodPercent
            piechart.addPieSlice(PieModel("food", Integer.parseInt(food).toFloat(), Color.parseColor(color1)))
        }
        if (intent.hasExtra(ScrollingActivity.KEY_ENT)) {
            var ent = intent.getStringExtra(ScrollingActivity.KEY_ENT)
            var entPercent = ((Integer.parseInt(ent)).toDouble() / (Integer.parseInt(total)).toDouble()).times(100.0).toInt().toString()
            tvEntNum.text = entPercent
            piechart.addPieSlice(PieModel("entertainment", Integer.parseInt(ent).toFloat(), Color.parseColor(color2)))
        }
        if (intent.hasExtra(ScrollingActivity.KEY_BILLS)) {
            var bills = intent.getStringExtra(ScrollingActivity.KEY_BILLS)
            var billsPercent = ((Integer.parseInt(bills)).toDouble() / (Integer.parseInt(total)).toDouble()).times(100.0).toInt().toString()
            tvBillsNum.text = billsPercent
            piechart.addPieSlice(PieModel("bills", Integer.parseInt(bills).toFloat(), Color.parseColor(color3)))
        }
        if (intent.hasExtra(ScrollingActivity.KEY_CLOTHES)) {
            var clothes = intent.getStringExtra(ScrollingActivity.KEY_CLOTHES)
            var clothesPercent = ((Integer.parseInt(clothes)).toDouble() / (Integer.parseInt(total)).toDouble()).times(100.0).toInt().toString()
            tvClothesNum.text = clothesPercent
            piechart.addPieSlice(PieModel("clothes", Integer.parseInt(clothes).toFloat(), Color.parseColor(color4)))
        }
        if (intent.hasExtra(ScrollingActivity.KEY_GIFTS)) {
            var gifts= intent.getStringExtra(ScrollingActivity.KEY_GIFTS)
            var giftsPercent = ((Integer.parseInt(gifts)).toDouble() / (Integer.parseInt(total)).toDouble()).times(100.0).toInt().toString()
            tvGiftsNum.text = giftsPercent
            piechart.addPieSlice(PieModel("gifts", Integer.parseInt(gifts).toFloat(), Color.parseColor(color5)))
        }
        if (intent.hasExtra(ScrollingActivity.KEY_OTHER)) {
            var other = intent.getStringExtra(ScrollingActivity.KEY_OTHER)
            var otherPercent = ((Integer.parseInt(other)).toDouble() / (Integer.parseInt(total)).toDouble()).times(100.0).toInt().toString()
            tvOtherNum.text = otherPercent
            piechart.addPieSlice(PieModel("other", Integer.parseInt(other).toFloat(), Color.parseColor(color6)))
        }

        piechart.startAnimation()


        btnBack.setOnClickListener {

            finish()

        }

        toggleButton.setOnClickListener {
            if (toggleButton.isChecked) {

                biglayout.setBackgroundColor(Color.parseColor("#091561"))
                cardViewGraph.setBackgroundColor(Color.parseColor("#347497"))
                details.setBackgroundColor(Color.parseColor("#347497"))

            } else {

                biglayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"))
                cardViewGraph.setBackgroundColor(Color.parseColor("#FFFFFFFF"))
                details.setBackgroundColor(Color.parseColor("#FFFFFFFF"))

            }
        }




    }



}