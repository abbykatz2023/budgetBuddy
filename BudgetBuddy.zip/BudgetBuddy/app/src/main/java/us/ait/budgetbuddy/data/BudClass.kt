package us.ait.budgetbuddy.data

import java.io.Serializable
import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey

@Entity(tableName = "bud")
data class BudClass(
    @PrimaryKey(autoGenerate = true) var budId: Long?,
    @ColumnInfo(name = "name") var name: String,
    @ColumnInfo(name = "price") var price: String,
    @ColumnInfo(name = "category") var category: Int): Serializable
