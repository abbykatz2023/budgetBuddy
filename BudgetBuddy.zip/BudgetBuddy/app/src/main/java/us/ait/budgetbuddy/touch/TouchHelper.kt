package us.ait.budgetbuddy.touch

interface TouchHelper {
    fun onDismissed(position: Int)
    fun onItemMoved(fromPosition: Int, toPosition: Int)
}