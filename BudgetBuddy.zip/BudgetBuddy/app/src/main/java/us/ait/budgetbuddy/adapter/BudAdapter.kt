package us.ait.budgetbuddy.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.bud_dialog.view.*
import kotlinx.android.synthetic.main.item_row.view.*
import us.ait.budgetbuddy.R
import us.ait.budgetbuddy.ScrollingActivity
import us.ait.budgetbuddy.data.AppDatabase
import us.ait.budgetbuddy.data.BudClass
import us.ait.budgetbuddy.touch.TouchHelper
import kotlin.concurrent.thread


class BudAdapter(var context: Context) : ListAdapter<BudClass, BudAdapter.ViewHolder>(BudDiffCallback()),
    TouchHelper {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_row, parent, false)
        return ViewHolder(view)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val bud = getItem(position)

        holder.etPrice.text = bud.price
        holder.etName.text = bud.name


        if (bud.category == 0) {
            holder.ivPhoto.setImageResource(R.drawable.food)
        } else if (bud.category==1) {
            holder.ivPhoto.setImageResource(R.drawable.entertainment)
        } else if (bud.category == 2) {
            holder.ivPhoto.setImageResource(R.drawable.bills)
        }
        else if (bud.category == 3) {
            holder.ivPhoto.setImageResource(R.drawable.clothes)
        }
        else if (bud.category == 4) {
            holder.ivPhoto.setImageResource(R.drawable.gifts)
        }
        else if (bud.category == 5) {
            holder.ivPhoto.setImageResource(R.drawable.other2)
        }

        holder.btnDelete.setOnClickListener {
            deleteBud(holder.adapterPosition)
        }

    }

    private var deletedBud: BudClass? = null
    private var deleteIndex = -1


    fun deleteBud(position: Int) {
        deletedBud = getItem(position)
        deleteIndex = position

        thread {
            AppDatabase.getInstance(context).todoDao().deleteBud(deletedBud!!)
        }

        (context as ScrollingActivity).showDeleteMessage(deletedBud!!)

        (context as ScrollingActivity).subtractValue(deletedBud!!)
    }


    fun restoreBud() {
        thread {
            AppDatabase.getInstance(context).todoDao().addBud(deletedBud!!)
        }
    }

    override fun onDismissed(position: Int) {
        deleteBud(position)
    }

    override fun onItemMoved(fromPosition: Int, toPosition: Int) {
        notifyItemMoved(fromPosition, toPosition)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val ivPhoto = itemView.ivPhoto

        val etName = itemView.etName

        val etPrice = itemView.etPrice


        val btnDelete = itemView.btnDelete

    }

}

class BudDiffCallback : DiffUtil.ItemCallback<BudClass>() {
    override fun areItemsTheSame(oldItem: BudClass, newItem: BudClass): Boolean {
        return oldItem.budId == newItem.budId
    }


    @SuppressLint("DiffUtilEquals")
    override fun areContentsTheSame(oldItem: BudClass, newItem: BudClass): Boolean {
        return oldItem == newItem
    }
}
