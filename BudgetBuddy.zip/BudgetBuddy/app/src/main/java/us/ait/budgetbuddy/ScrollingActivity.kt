package us.ait.budgetbuddy

import android.content.Intent
import android.os.Bundle
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.AnimationUtils
import androidx.recyclerview.widget.ItemTouchHelper
import kotlinx.android.synthetic.main.activity_scrolling.*
import us.ait.budgetbuddy.adapter.BudAdapter
import us.ait.budgetbuddy.data.AppDatabase
import us.ait.budgetbuddy.data.BudClass
import kotlin.concurrent.thread
import androidx.lifecycle.Observer
import us.ait.budgetbuddy.touch.TouchCallback

class ScrollingActivity : AppCompatActivity(), BudDialog.BudHandler {

    companion object {
        const val KEY_TOTAL = "KEY_TOTAL"
        const val KEY_FOOD = "KEY_FOOD"
        const val KEY_ENT = "KEY_ENT"
        const val KEY_BILLS = "KEY_BILLS"
        const val KEY_CLOTHES = "KEY_CLOTHES"
        const val KEY_GIFTS = "KEY_GIFTS"
        const val KEY_OTHER = "KEY_OTHER"
    }


    lateinit var budAdapter: BudAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scrolling)
        setSupportActionBar(findViewById(R.id.toolbar))
        findViewById<CollapsingToolbarLayout>(R.id.toolbar_layout).title = title

        initRecyclerView()

        val myAnim = AnimationUtils.loadAnimation(this, R.anim.btn_anim)


        fab.setOnClickListener {
            BudDialog().show(supportFragmentManager, "TAG_TODO_DIALOG")
            fab.startAnimation(myAnim)
        }

        fab2.setOnClickListener{
            fab2.startAnimation(myAnim)
            thread {
                AppDatabase.getInstance(this).todoDao().nukeTable()
                total = 0
                food= 0
                ent= 0
                bills = 0
                clothes = 0
                gifts = 0
                other = 0
            }

        }
        fab3.setOnClickListener{

            val intentStart = Intent()
            intentStart.setClass(this, SummaryActivity::class.java)

            intentStart.putExtra(KEY_TOTAL, total.toString())
            intentStart.putExtra(KEY_FOOD, food.toString())
            intentStart.putExtra(KEY_ENT, ent.toString())
            intentStart.putExtra(KEY_BILLS, bills.toString())
            intentStart.putExtra(KEY_CLOTHES, clothes.toString())
            intentStart.putExtra(KEY_GIFTS, gifts.toString())
            intentStart.putExtra(KEY_OTHER, other.toString())

            startActivity(intentStart)
        }
    }

    var total:Int = 0
    var food:Int = 0
    var ent:Int = 0
    var bills:Int = 0
    var clothes:Int = 0
    var gifts:Int = 0
    var other:Int = 0

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_scrolling, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun initRecyclerView() {
        budAdapter = BudAdapter(this)
        recyclerBud.adapter = budAdapter

        AppDatabase.getInstance(this).todoDao().getAllBud()
            .observe(this, Observer { items ->
                budAdapter.submitList(items)
            })

        val touchCallbakList = TouchCallback(budAdapter)
        val itemTouchHelper = ItemTouchHelper(touchCallbakList)
        itemTouchHelper.attachToRecyclerView(recyclerBud)
    }

    override fun budCreated(bud: BudClass) {
        thread {
            AppDatabase.getInstance(this).todoDao().addBud(bud)
        }
        if (bud.category == 0){
            food = food+ Integer.parseInt(bud.price.toString())
            total = total + Integer.parseInt(bud.price.toString())
        } else if (bud.category == 1){
            ent = ent+ Integer.parseInt(bud.price.toString())
            total = total + Integer.parseInt(bud.price.toString())
        } else if (bud.category == 2){
            bills = bills+ Integer.parseInt(bud.price.toString())
            total = total + Integer.parseInt(bud.price.toString())
        } else if (bud.category == 3){
            clothes = clothes+ Integer.parseInt(bud.price.toString())
            total = total + Integer.parseInt(bud.price.toString())
        } else if (bud.category == 4){
            gifts = gifts+ Integer.parseInt(bud.price.toString())
            total = total + Integer.parseInt(bud.price.toString())
        } else if (bud.category == 5){
            other = other+ Integer.parseInt(bud.price.toString())
            total = total + Integer.parseInt(bud.price.toString())
        }
    }
    public fun showDeleteMessage(bud:BudClass) {
        Snackbar.make(recyclerBud, "Item removed", Snackbar.LENGTH_LONG)
            .setAction("Undo", object: View.OnClickListener {
                override fun onClick(v: View?) {
                    budAdapter.restoreBud()
                    if (bud.category == 0){
                        food = food+ Integer.parseInt(bud.price.toString())
                        total = total + Integer.parseInt(bud.price.toString())
                    } else if (bud.category == 1){
                        ent = ent+ Integer.parseInt(bud.price.toString())
                        total = total + Integer.parseInt(bud.price.toString())
                    } else if (bud.category == 2){
                        bills = bills+ Integer.parseInt(bud.price.toString())
                        total = total + Integer.parseInt(bud.price.toString())
                    } else if (bud.category == 3){
                        clothes = clothes+ Integer.parseInt(bud.price.toString())
                        total = total + Integer.parseInt(bud.price.toString())
                    } else if (bud.category == 4){
                        gifts = gifts+ Integer.parseInt(bud.price.toString())
                        total = total + Integer.parseInt(bud.price.toString())
                    } else if (bud.category == 5){
                        other = other+ Integer.parseInt(bud.price.toString())
                        total = total + Integer.parseInt(bud.price.toString())
                    }
                }
            })
            .show()
    }
    public fun subtractValue(bud:BudClass){
        if (bud.category == 0){
            food = food- Integer.parseInt(bud.price.toString())
            total = total - Integer.parseInt(bud.price.toString())
        } else if (bud.category == 1){
            ent = ent- Integer.parseInt(bud.price.toString())
            total = total - Integer.parseInt(bud.price.toString())
        } else if (bud.category == 2){
            bills = bills- Integer.parseInt(bud.price.toString())
            total = total - Integer.parseInt(bud.price.toString())
        } else if (bud.category == 3){
            clothes = clothes- Integer.parseInt(bud.price.toString())
            total = total - Integer.parseInt(bud.price.toString())
        } else if (bud.category == 4){
            gifts = gifts- Integer.parseInt(bud.price.toString())
            total = total - Integer.parseInt(bud.price.toString())
        } else if (bud.category == 5){
            other = other- Integer.parseInt(bud.price.toString())
            total = total - Integer.parseInt(bud.price.toString())
        }

    }
}

