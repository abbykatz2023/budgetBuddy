package us.ait.budgetbuddy.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface BudDao {

    @Query("DELETE FROM bud")
    fun nukeTable()

    @Query("SELECT * FROM bud")
    fun getAllBud(): LiveData<List<BudClass>>

    @Insert
    fun addBud(todo: BudClass): Long

    @Delete
    fun deleteBud(todo: BudClass)

    @Update
    fun updateBud(todo: BudClass)

}



